import './App.css'

function App() {

  return (
    <>
      <div className='container'>
        <div className='head'>
          <h1>Rick Y Morty API</h1>
        </div>
      </div>
    </>
  );
}

export default App;
