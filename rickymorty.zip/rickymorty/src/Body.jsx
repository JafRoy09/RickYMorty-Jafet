import { useState, useEffect } from 'react';
import { GetLocationDefault, GetLocation } from './FetchAPI';
import './Body.css'

function Body() {

    const [inNumber, setInNumber] = useState('');

    const handleInputChange = (e) => {
        setInNumber(e.target.value);
    };

    async function handleClic() {
        const srtLocali = await GetLocation(inNumber ? inNumber : 1);
        setResidents(srtLocali);
    }

    const [residents, setResidents] = useState([]);

    async function Default() {
        const srtDefault = await GetLocationDefault();
        setResidents(srtDefault);
    }

    let cardColor;

    if (inNumber < 50) {
        cardColor = 'var(--green-color)';
    } else if (inNumber >= 50 && inNumber < 80) {
        cardColor = 'var(--blue-color)';
    } else if (inNumber >= 80) {
        cardColor = 'var(--red-color)';
    } else {
        cardColor = 'var(--default-card-color)'; 
    }

    document.documentElement.style.setProperty('--default-card-color', cardColor);

    useEffect(() => {
        Default();
    }, []);

    return (
        <>
            <div className="search-container">
                <input
                    className="search-input"
                    type="number"
                    placeholder="Digite un número de localidad"
                    value={inNumber}
                    onChange={handleInputChange}
                />
                <button className="search-button" onClick={handleClic}>
                    Buscar
                </button>
            </div>

            <div className='card-container'>
                {
                    residents && residents.length > 0 ? (
                        residents.map((resident, index) => (
                            <div className="card" key={index}>
                                <img src={resident.image} alt={resident.name} />
                                <h2>{resident.name}</h2>
                                <div className='more-info'>
                                    <p>Origin: {resident.origin.name ? resident.origin.name : 'N/A'}</p>
                                    <p>Status: {resident.status ? resident.status : 'N/A'}</p>
                                    <p>Gender: {resident.gender ? resident.gender : 'N/A'}</p>
                                    <h3>Episodios:</h3>
                                    <ul className='ul-episode'>
                                        {resident.episodes.map((episode, episodeIndex) => (
                                            <li className='li-episode' key={episodeIndex}>
                                                <a className='link-episode' href={episode.url}>
                                                    {episode.name ? episode.name : 'N/A'}
                                                </a>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className='card'>
                            <img src='https://wallpapercave.com/wp/wp8729634.jpg' alt='Imagen predeterminada'/>
                            <h2>No Existen Residentes</h2>
                        </div>
                    )
                }
            </div>

        </>
    )
}

export default Body