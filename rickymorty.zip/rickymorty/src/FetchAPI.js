const getUrlLocation = 'https://rickandmortyapi.com/api/location/';

export async function GetLocationDefault() {
    try {
        const response = await fetch(`${getUrlLocation}${1}`);
        const data = await response.json();

        // Obtener los primeros 5 residentes
        const residents = data.residents.slice(0, 5);

        const residentPromises = residents.map(async (residentURL) => {
            const residentResponse = await fetch(residentURL);
            const residentData = await residentResponse.json();

            // Obtener información de los episodios
            const episodePromises = residentData.episode.slice(0, 3).map(async (episodeURL) => {
                const episodeResponse = await fetch(episodeURL);
                const episodeData = await episodeResponse.json();
                return episodeData;
            });

            const episodes = await Promise.all(episodePromises);

            return {
                name: residentData.name,
                image: residentData.image,
                species: residentData.species,
                origin: residentData.origin,
                status: residentData.status,
                gender: residentData.gender,
                episodes: episodes,
            };
        });

        const residentDetails = await Promise.all(residentPromises);

        return residentDetails;
    } catch (error) {
        console.error(error);
        return [];
    }
}

export async function GetLocation(inNumber) {
    try {
        const response = await fetch(`${getUrlLocation}${inNumber}`);
        const data = await response.json();

        // Obtener los primeros 5 residentes
        const residents = data.residents.slice(0, 5);
        
        const residentPromises = residents.map(async (residentURL) => {
            const residentResponse = await fetch(residentURL);
            const residentData = await residentResponse.json();

            // Obtener información de los episodios
            const episodePromises = residentData.episode.slice(0, 3).map(async (episodeURL) => {
                const episodeResponse = await fetch(episodeURL);
                const episodeData = await episodeResponse.json();
                return episodeData;
            });

            const episodes = await Promise.all(episodePromises);

            return {
                name: residentData.name,
                image: residentData.image,
                species: residentData.species,
                origin: residentData.origin,
                status: residentData.status,
                gender: residentData.gender,
                episodes: episodes,
            };
        });

        const residentDetails = await Promise.all(residentPromises);

        return residentDetails;
    } catch (error) {
        console.error(error);
        return [];
    }
}